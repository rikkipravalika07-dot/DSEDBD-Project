# Expense Splitter & Group Budget Manager - Full Stack

Architecture:
React.js + HTML5/CSS3/JavaScript ES6 -> Node.js + Express.js REST API -> MySQL
JWT is used for authentication. Postman collection is included in `backend/postman_collection.json`.

## Start backend first

Open `complete/backend` in a VS Code terminal and run:

```powershell
powershell -ExecutionPolicy Bypass -File .\setup.ps1
npm install
npm run dev
```

Keep this terminal running.

## Start frontend second

Open another VS Code terminal:

```powershell
cd ..\frontend
npm install
npm run dev
```

Then open the localhost URL shown by Vite.

## MySQL

MySQL Server must be running. The setup script creates `backend/.env` from your MySQL credentials. The backend automatically creates the `expense_splitter` database and required tables.
