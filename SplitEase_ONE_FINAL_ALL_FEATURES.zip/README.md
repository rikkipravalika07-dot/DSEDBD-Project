# SplitEase — Expense Splitter & Shared Budget Manager

A beginner-friendly full-stack app for personal expenses and shared group finances.

## Included features

- Real account registration/login using bcrypt password hashing and JWT-protected APIs.
- MySQL-backed groups and account-to-account collaboration. Existing users are added immediately; invitations for new emails become group memberships after they register with the same email.
- Group roles: the creator is the admin and controls member invitations and the shared group budget; members can add expenses and view the shared finances.
- Equal and custom expense splitting, member balances, transaction history, and balance-based settlement suggestions.
- Shared group budget monitoring visible to every member, with notifications when group spending crosses 75%, 90%, and 100% of the shared limit.
- Personal/category budgets and group budget summaries.
- Payment Center: UPI ID, amount-specific UPI QR, open/copy UPI options, payment requests, optional UTR/reference, initiated / awaiting confirmation / paid / cancelled / failed statuses, and recipient confirmation.
- Smart receipt scan for images using browser OCR. OCR results must be reviewed. PDFs can be uploaded and the details entered manually.
- Receipt files and OCR text saved in MySQL-linked receipt records; receipts can be attached to a new expense.
- Notifications, spending-category insights, light/dark appearance, responsive layout, Help & Quick Start, and English/Telugu/Hindi/Tamil/Malayalam for major navigation and labels.

## Important payment limitation

The UPI QR opens a UPI payment intent; this project does not connect to a bank or payment gateway and cannot independently verify a bank transfer. A sender can mark a payment as claimed, and the recipient must check their own UPI app/bank statement before confirming it. The app never asks for a UPI PIN, OTP, or bank password.

## Requirements

- Node.js 18 or newer (Node 20/22 recommended)
- MySQL Server 8.x (MySQL Workbench is optional but useful)
- VS Code

## First-time setup on Windows

1. Extract the ZIP.
2. Open the extracted `complete` folder in VS Code. It contains `backend`, `frontend`, and `database`.
3. Start MySQL Server and remember your MySQL username/password.
4. In VS Code, open Terminal 1 and run:

   ```powershell
   cd backend
   powershell -ExecutionPolicy Bypass -File .\setup.ps1
   npm install
   npm run dev
   ```

   Enter your actual MySQL username/password when asked. Keep this terminal open. If `backend/.env` is already configured successfully, skip the setup script and run only `npm run dev`.

5. Open Terminal 2 (plus icon in the Terminal panel) and run:

   ```powershell
   cd frontend
   npm install
   npm run dev
   ```

6. Open the Vite URL shown in Terminal 2, normally `http://localhost:5173`.

## First-time collaboration test

1. Register Account A.
2. Create a group and set its initial budget.
3. Open the group and invite Account B by email.
4. If Account B already exists, they are added immediately. Otherwise, register Account B with that exact email; the pending invitation is activated on registration.
5. Login as Account B and open Groups. The shared group should appear.
6. Add a group expense. Both accounts can view the expense, group spending, member balances, and shared budget after refreshing/reopening the page.

## UPI setup and test

1. Each user opens Profile and saves their own UPI ID (for example `name@bank`). Do not enter a UPI PIN.
2. Open Settlements / Payment Center. The payer chooses Pay, scans the QR or opens a UPI app, and checks the payee and amount before paying.
3. After paying externally, the payer selects “I have paid — request confirmation”. The status becomes “Awaiting recipient confirmation”.
4. The recipient checks their own UPI app/bank statement and confirms the payment. The app then records it as “Paid · user-confirmed”. This is not automatic bank verification.

## Run the project on later days

Start MySQL, then start the backend in one terminal (`cd backend`, `npm run dev`) and the frontend in another (`cd frontend`, `npm run dev`). You do not need to run `setup.ps1` again unless the backend `.env` is missing or you need to change your MySQL configuration.

## Troubleshooting

- `DB_PASSWORD is empty`: run the setup script from inside the `backend` folder or create `backend/.env` using `.env.example`.
- `Failed to fetch`: make sure the backend terminal is running on port 5000 and the frontend on port 5173.
- Invite fails: ensure the signed-in account is the group creator/admin and the email is valid. Check the backend terminal for a database error.
- UPI field not saving: open Profile, enter a UPI ID like `name@bank`, click Save, and check for the success/error message.
- If dependencies fail to install, confirm internet access and Node.js version, then rerun `npm install` inside the affected folder.
