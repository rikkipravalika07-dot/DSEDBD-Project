import mysql from 'mysql2/promise';
import dotenv from 'dotenv';
dotenv.config();

const config = {
  host: process.env.DB_HOST || 'localhost',
  port: Number(process.env.DB_PORT || 3306),
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'expense_splitter',
  waitForConnections: true,
  connectionLimit: 10,
  decimalNumbers: true
};

export const pool = mysql.createPool(config);

export async function initializeDatabase() {
  if (!process.env.DB_PASSWORD) {
    throw new Error('DB_PASSWORD is empty. Run setup.ps1 in the backend folder and enter your MySQL password, or create backend/.env.');
  }
  // Make sure the database itself exists.
  const bootstrap = await mysql.createConnection({
    host: config.host,
    port: config.port,
    user: config.user,
    password: config.password
  });
  await bootstrap.query(`CREATE DATABASE IF NOT EXISTS \`${config.database}\``);
  await bootstrap.end();

  const statements = [
    `CREATE TABLE IF NOT EXISTS users (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(100) NOT NULL,
      email VARCHAR(190) NOT NULL UNIQUE,
      upi_id VARCHAR(100) NULL,
      password_hash VARCHAR(255) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `CREATE TABLE IF NOT EXISTS groups_table (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      name VARCHAR(120) NOT NULL,
      type VARCHAR(50) DEFAULT 'Friends',
      description VARCHAR(255),
      created_by BIGINT UNSIGNED NOT NULL,
      budget DECIMAL(12,2) DEFAULT 0,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS group_members (
      group_id BIGINT UNSIGNED NOT NULL,
      user_id BIGINT UNSIGNED NOT NULL,
      joined_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      PRIMARY KEY (group_id,user_id),
      FOREIGN KEY (group_id) REFERENCES groups_table(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS expenses (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      group_id BIGINT UNSIGNED NULL,
      title VARCHAR(150) NOT NULL,
      amount DECIMAL(12,2) NOT NULL,
      expense_date DATE NOT NULL,
      category VARCHAR(50) NOT NULL,
      notes VARCHAR(500),
      receipt_id BIGINT UNSIGNED NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (group_id) REFERENCES groups_table(id) ON DELETE SET NULL
    )`,
    `CREATE TABLE IF NOT EXISTS expense_splits (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      expense_id BIGINT UNSIGNED NOT NULL,
      user_id BIGINT UNSIGNED NOT NULL,
      share_amount DECIMAL(12,2) NOT NULL,
      FOREIGN KEY (expense_id) REFERENCES expenses(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS budgets (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      group_id BIGINT UNSIGNED NULL,
      name VARCHAR(120) NOT NULL,
      category VARCHAR(50) NOT NULL,
      limit_amount DECIMAL(12,2) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (group_id) REFERENCES groups_table(id) ON DELETE SET NULL
    )`,
    `CREATE TABLE IF NOT EXISTS settlements (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      group_id BIGINT UNSIGNED NULL,
      from_user_id BIGINT UNSIGNED NOT NULL,
      to_user_id BIGINT UNSIGNED NOT NULL,
      amount DECIMAL(12,2) NOT NULL,
      status ENUM('pending','initiated','awaiting_confirmation','paid','cancelled','failed','settled') DEFAULT 'pending',
      payment_reference VARCHAR(120) NULL,
      sender_marked_at TIMESTAMP NULL,
      settled_at TIMESTAMP NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (group_id) REFERENCES groups_table(id) ON DELETE SET NULL,
      FOREIGN KEY (from_user_id) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (to_user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS group_collaborators (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      group_id BIGINT UNSIGNED NOT NULL,
      email VARCHAR(190) NOT NULL,
      name VARCHAR(100) NULL,
      user_id BIGINT UNSIGNED NULL,
      invited_by BIGINT UNSIGNED NOT NULL,
      status ENUM('invited','active') DEFAULT 'invited',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      UNIQUE KEY uq_group_collaborator (group_id,email),
      FOREIGN KEY (invited_by) REFERENCES users(id) ON DELETE CASCADE,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
    )`,
    `CREATE TABLE IF NOT EXISTS receipts (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      original_name VARCHAR(255) NOT NULL,
      stored_name VARCHAR(255) NOT NULL,
      mime_type VARCHAR(100) NOT NULL,
      file_size BIGINT UNSIGNED NOT NULL,
      extracted_text LONGTEXT NULL,
      merchant VARCHAR(255) NULL,
      receipt_date DATE NULL,
      total_amount DECIMAL(12,2) NULL,
      category VARCHAR(50) NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE TABLE IF NOT EXISTS notifications (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      user_id BIGINT UNSIGNED NOT NULL,
      type VARCHAR(60) NOT NULL,
      text VARCHAR(500) NOT NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      read_at TIMESTAMP NULL,
      FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    )`,
    `CREATE INDEX IF NOT EXISTS idx_expenses_user_category ON expenses(user_id,category)`,
    `CREATE INDEX IF NOT EXISTS idx_budgets_user ON budgets(user_id)`,
    `CREATE INDEX IF NOT EXISTS idx_notifications_user_read ON notifications(user_id,read_at)`
  ];

  for (const sql of statements) {
    try {
      await pool.query(sql);
    } catch (err) {
      // MySQL versions that don't support CREATE INDEX IF NOT EXISTS may throw
      // for existing indexes. Tables must still be created successfully.
      if (!sql.includes('CREATE INDEX IF NOT EXISTS')) throw err;
    }
  }

  // Lightweight migrations for databases created by older project versions.
  const migrations = [
    `ALTER TABLE expenses ADD COLUMN receipt_id BIGINT UNSIGNED NULL`,
    `ALTER TABLE users ADD COLUMN upi_id VARCHAR(100) NULL`,
    `ALTER TABLE settlements MODIFY status ENUM('pending','initiated','awaiting_confirmation','paid','cancelled','failed','settled') DEFAULT 'pending'`,
    `ALTER TABLE settlements ADD COLUMN payment_reference VARCHAR(120) NULL`,
    `ALTER TABLE settlements ADD COLUMN sender_marked_at TIMESTAMP NULL`,
    `CREATE TABLE IF NOT EXISTS group_collaborators (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      group_id BIGINT UNSIGNED NOT NULL,
      email VARCHAR(190) NOT NULL,
      name VARCHAR(100) NULL,
      user_id BIGINT UNSIGNED NULL,
      invited_by BIGINT UNSIGNED NOT NULL,
      status ENUM('invited','active') DEFAULT 'invited',
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    )`,
    `ALTER TABLE group_collaborators ADD COLUMN name VARCHAR(100) NULL`,
    `ALTER TABLE group_collaborators ADD COLUMN user_id BIGINT UNSIGNED NULL`,
    `ALTER TABLE group_collaborators ADD COLUMN invited_by BIGINT UNSIGNED NULL`,
    `ALTER TABLE group_collaborators ADD COLUMN status ENUM('invited','active') DEFAULT 'invited'`,
    `ALTER TABLE group_collaborators ADD COLUMN created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP`,
  ];
  for (const sql of migrations) {
    try { await pool.query(sql); } catch (err) {
      if (!/Duplicate column name|Duplicate column|already exists|Duplicate key name|ER_DUP_FIELDNAME/i.test(err.message)) throw err;
    }
  }
  // Make invitation records unique per group/email when possible. Older databases may already have duplicate rows; in that case the index is skipped and the endpoint still works.
  try { await pool.query(`ALTER TABLE group_collaborators ADD UNIQUE KEY uq_group_collaborator (group_id,email)`); } catch (err) {
    if (!/Duplicate key name|Duplicate entry|already exists/i.test(err.message)) throw err;
  }

  await pool.query('SELECT 1');
}
