# Backend

Express REST API with JWT authentication and MySQL. See the root README for first-time setup and test workflows.

Run inside this folder: `npm install`, then `npm run dev`. Configure `.env` using `setup.ps1`. The API health check is `http://localhost:5000/api/health`.
