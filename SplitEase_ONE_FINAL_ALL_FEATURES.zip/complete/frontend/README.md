# Frontend

React + Vite UI. Run `npm install` and `npm run dev` inside this folder after starting the backend. Open `http://localhost:5173`. See the root README for the full walkthrough.
